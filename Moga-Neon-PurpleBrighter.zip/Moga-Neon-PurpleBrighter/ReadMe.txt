Moga Neon PurpleBrighter (vr 1.0) for Linux.

Created by MOYASH.
------------------

to install: 

1-Move "Moga-Neon-PurpleBrighter" folder to the ".icons" folder in your "Home" directory.
1-OR, you can move it to "/usr/share/icons" folder.

2-Then Choose and Apply the Cursor Name.
---------------------------------------

License:(CC BY-NC-ND).
---------------------

Support Creator: ($3.0 or more)

***** Buy a Coffee for MOYASH *****
ko-fi.com/moyash
buymeacoffee.com/moyash


***** Direct Donation via PayPal *****
paypal.me/MOYASH77
----------------------------------------------------------

Thanks for Downloading my Work.
Copyright 2026 Moyash, All right reserved.
-----------------------------------------------------